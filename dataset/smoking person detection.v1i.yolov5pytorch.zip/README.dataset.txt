# smoking person detection > 2023-04-06 4:37pm
https://universe.roboflow.com/project-i6bzi/smoking-person-detection-ec7ec

Provided by a Roboflow user
License: CC BY 4.0

